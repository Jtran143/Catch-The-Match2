A Pen created at CodePen.io. You can find this one at https://codepen.io/bh/pen/buHJd.

 Fluid social network buttons. On hover the network logo disappears into the distance, and text with the name of the network appears with blur/opacity filters.

Uses Sass (SCSS) + Autoprefixer